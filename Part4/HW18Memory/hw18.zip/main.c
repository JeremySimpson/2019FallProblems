#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "memory.h"

int main()
{
return EXIT_SUCCESS;
}
