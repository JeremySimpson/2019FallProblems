// ***
// *** You MUST modify this file
// ***

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h> 
#include <string.h> 

#ifdef TEST_ELIMINATE
// 100% of the score
void eliminate(int n, int k)

// 100% of the score
//void eliminate(int n, int k)
{
  // allocate an arry of n elements
  int * arr = malloc(sizeof(* arr) * n);
  // check whether memory allocation succeeds.
  // if allocation fails, stop
  if (arr == NULL)
    {
      fprintf(stderr, "malloc fail\n");
      return;
    }
    
  // initialize all elements
    int i; //counter for index
    int ar; //counter for amount of repetitions 
    int count; //counter for skips
  
  // counting to k,
  // mark the eliminated element
  // print the index of the marked element
  // repeat until only one element is unmarked
    //printf("reached 2");
    for (i = 0; i < n; i++)
    {
        arr[i] = i; //assigns the value of the index to the indexed element
    }
    
    i = -1; //sets initial i counter value at -1, accounts for i++
    for (ar = 1; ar <= n; ar++) //continues for each element in array
    {
        
        count = 0; //resets count value to 0
        while (count < k) //continues until count is 1 less than k
            {
                i++;
                i = i % n; //converts i to index between 1 - (n-1)
                if (arr[i] != -1) //performs if indexed value isn't skipped
                {
                    count++; //adds 1 to count if indexed value isn't skipped           
                }
            
            } 
        arr[i] = -1; //makes current index skippable on next run
		// print the last one
		printf("%d\n",i);
    }
  // release the memory of the array
  free (arr);
}
#endif
