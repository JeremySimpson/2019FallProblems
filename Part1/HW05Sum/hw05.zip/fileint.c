// ***
// *** You MUST modify this file.
// ***

#include <stdio.h>
#include <stdbool.h>

#ifdef TEST_ADDFILE
bool addFile(char * filename, int * sum)
{
	FILE * fptr = fopen(filename, "r"); //opens a file named "filename" and reads it

	if (fptr == NULL) //returns FALSE if file cannot be opened
	{
		return false;
	}
	
	* sum = 0; //sets sum to 0
	int sumtemp = 0; //creates temporary variable
	
	while ((fscanf(fptr,"%d",&sumtemp) == 1)) //assigns the character at fptr to sumtemp
	{
		
		*sum += sumtemp; //adds temporary value to sum
	}
	
	
	fclose (fptr); //closes the file

  return true;
}
#endif


#ifdef TEST_WRITESUM
bool writeSum(char * filename, int sum)
{
	FILE * fptr = fopen(filename, "w"); //opens writable file
	
	if (fptr == NULL) //returns FALSE if file cannot be opened
	{
		return false;
	}
	
        fprintf(fptr, "%d\n", sum);//prints sum as integer in fptr
	fclose(fptr); //closes file
  
  return true;
}
#endif
